# __init__.py
from .src1_interface import *